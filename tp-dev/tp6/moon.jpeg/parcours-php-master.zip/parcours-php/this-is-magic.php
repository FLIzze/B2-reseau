<?php
class Magic
{
    public string $card;

    public function __construct(string $card = 'As') {
        $this->card = $card;
        echo "__constructor";
    }

    function __destruct() {
        echo "__destruct";
    }

    public function __get(string $name) {
        echo "__get";
        if ($name === 'card') {
            return $this->card;
        }
        return null;
    }

    public function __set(string $name, string $value) {
        echo "__set";
        if ($name === 'card') {
            $this->card = $value;
        }
    }

    public function __isset(string $name): bool {
        echo "__isset";
        return $name === 'card';
    }

    public function __toString(): string {
        echo "__toString";
        return $this->card;
    }


}

?>