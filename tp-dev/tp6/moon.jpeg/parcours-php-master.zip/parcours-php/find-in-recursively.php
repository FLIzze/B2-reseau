<?php
$tab = [
    "name" => "forIn",
    "type" => "function",
    "arguments" => [
        "firstParam" => [
            "paramType" => "string",
            "description" => "the value key to find"
        ],
        "secondParam" => "array"
    ],
    "return" => "string or bool"
];

function findIn(string $str, array $arr): string|bool {
    foreach ($arr as $key => $value) {
        if ($key == $str) {
            return $value;
        }
        elseif (is_array($value)) {
            if (findIn($str, $value)) {
                return findIn($str, $value);
            } 
        }
    }
    return false;
}
?>