<?php
function manageMovements(string $moovs): array {
    $instructions = [];
    foreach (str_split($moovs) as $moov) {
        if ($moov === "R") {
            if ($instructions[count($instructions) - 1 ] === "RIGHT") {
                $instructions[] = "RIGHT AGAIN";
            } else {
                $instructions[] = "RIGHT";
            }
        } elseif ($moov === "L") {
            if ($instructions[count($instructions) - 1 ] === "LEFT") {
                $instructions[] = "LEFT AGAIN";
            } else {
                $instructions[] = "LEFT";
            }
        } elseif ($moov === "F") {
            if ($instructions[count($instructions) - 1 ] === "FRONT") {
                $instructions[] = "FRONT AGAIN";
            } else {
                $instructions[] = "FRONT";
            }
        } elseif ($moov === "B") {
            if ($instructions[count($instructions) - 1 ] === "BACKWARDS") {
                $instructions[] = "BACKWARDS AGAIN";
            } else {
                $instructions[] = "BACKWARDS";
            }
        }
    }
    return $instructions;
}
print_r(manageMovements("RFFLFR"));
?>