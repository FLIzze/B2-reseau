<?php
class Song
{
    private string $artist;
    private string $title;
    private string $duration;

    public function __construct(string $artist, string $title, string $duration) {
        $this->artist = $artist;
        $this->title = $title;
        $this->duration = $duration;
    }

    public function getArtist(): string {
        return $this->artist;
    }

    public function getTitle(): string {
        return $this->title;
    }

    public function getDuration(): string {
        return $this->duration;
    }

    public function setArtist(string $artist): self {
        $this->artist = $artist;

        return $this;
    }

    public function setTitle(string $title): self {
        $this->title = $title;

        return $this;
    }

    public function setDuration(string $duration): self {
        $this->duration = $duration;

        return $this;
    }
}

class Playlist
{
    private array $songs;
    private ?int $totalMedias = null;

    public function addMedia(Song $song): void {
        $this->songs[] = $song;
        $this->totalMedias++;
    }

    public function getPlaylistLength(): string {
        $totalSeconds = 0;
        foreach ($this->songs as $song) {
            $duration = explode(":", $song->getDuration());
            $totalSeconds += $duration[0] * 60 + $duration[1];
        }

        $minutes = floor($totalSeconds / 60);
        $hours = floor($totalSeconds / 3600);
        $totalSeconds %= 3600;
        $minutes = floor($totalSeconds / 60);
        $seconds = $totalSeconds % 60;

        return "{$hours}h {$minutes}m {$seconds}s";
    }

    public function __toString(): string {
        return "Songs added: {$this->totalMedias}\nPlaylist length: {$this->getPlaylistLength()}";
    }
}

class App
{
    private array $content;

    public function start() {
        $playlist = new Playlist();

        foreach ($this->readLine(true) as $line) {
            $song = explode(";", $line);
            $playlist->addMedia(new Song($song[0], $song[1], $song[2]));
        }

        echo $playlist;
    }

    public function setContent(array $content): self {
        $this->content = $content;

        return $this;
    }

    public function getContent(): array {
        return $this->content;
    }

    private function readLine(bool $asArray = false): array|bool|string
    {
        ob_start();

        echo implode("", $this->getContent());

        $data = ob_get_contents();
        if ($asArray) {
            $data = explode("\n", ob_get_contents());
        }

        ob_clean();

        return $data;
    }

    public function write(string $content): self {
        $this->content[] = $content;

        return $this;
    }
}

$app = new App();
$app->setContent(["ABBA;Mamma Mia;3:35\n", "Harry Styles;Watermelon Sugar;2:54\n", "LF SYSTEM;Affraid To Feel;2:58"]);
$app->start();

$app2 = new App();
$app2->setContent(["JUL;Alors la zone;3:25\n", "Naps;La kiffance;2:59\n", "2TH;Si seulement;4:09\n", "Vayn;24H chrono;3:48"]);
$app2->start();

?>