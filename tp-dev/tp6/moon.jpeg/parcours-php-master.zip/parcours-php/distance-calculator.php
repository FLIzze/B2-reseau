<?php
class Geolocation
{
    public static function fromGeoPoints(float $c1, float $c2, float $c3, float $c4): float {
        $latFrom = deg2rad($c1);
        $lonFrom = deg2rad($c2);
        $latTo = deg2rad($c3);
        $lonTo = deg2rad($c4);

        $latDelta = $latTo - $latFrom;
        $lonDelta = $lonTo - $lonFrom;

        $angle = 2 * asin(sqrt(pow(sin($latDelta / 2), 2) +
        cos($latFrom) * cos($latTo) * pow(sin($lonDelta / 2), 2)));

        return sprintf('%.1f', $angle * 6371);
    }
}

$calc = Geolocation::fromGeoPoints(40.76, -73.984, 38.89, -77.032); // 333.1
echo $calc;
?>