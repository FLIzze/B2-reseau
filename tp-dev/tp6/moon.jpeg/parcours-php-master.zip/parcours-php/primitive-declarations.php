<?php
$firstStr = "";
$firstEscapeStr = "\n";
$firstBool = true;
$firstInteger = 9;
$firstFloat = 0.5;
$firstNull = null;
$firstArray = array(2, null, 'Hi', 5.5, false);
?>