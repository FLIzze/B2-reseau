<?php
function getFloor(int $currentFloor, int|null $requestedFloor, array $floors): int|null {
    $closestFloor = null;
    $minDifference = PHP_INT_MAX;
    foreach ($floors as $floor) {
        $difference = abs($floor - $currentFloor);
        if ($difference < $minDifference) {
            $minDifference = $difference;
            $closestFloor = $floor;
        }
    }

    if ($requestedFloor !== null) {
        $requestedDifference = abs($requestedFloor - $currentFloor);
        if ($requestedDifference < $minDifference) {
            $closestFloor = $requestedFloor;
        }
    }

    return $closestFloor;
}

function getDirection(int $currentFloor, int|null $requestedFloor, array $floors): int {
    if ($requestedFloor === $currentFloor && $floors === []) {
        return 0;
    }
    return getFloor($currentFloor, $requestedFloor, $floors) > $currentFloor ? 1 : -1;
}
?>
