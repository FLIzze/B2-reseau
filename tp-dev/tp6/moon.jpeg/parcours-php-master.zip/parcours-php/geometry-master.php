<?php
abstract class AbstractGeometry {
    abstract public function area();
    abstract public function perimeter();
}

class Rectangle extends AbstractGeometry {

    public int $width;
    public int $height;

    public function __construct(int $width = 0, int $height = 0) {
        $this->width = $width;
        $this->height = $height;
    }

    public function area() {
        return $this->width * $this->height;
    }

    public function perimeter() {
        return $this->width * 2 + $this->height * 2;
    }
}

class Square extends AbstractGeometry {

    public int $width;

    public function __construct(int $width = 0) {
        $this->width = $width;
    }

    public function area() {
        return $this->width * $this->width;
    }
    public function perimeter() {
        return $this->width * 2 + $this->width * 2;
    }
}

class Triangle extends AbstractGeometry {

    public int|float $v1;
    public int|float $v2;
    public int|float $v3;

    public function __construct(int|float $v1 = 0, int|float $v2 = 0, int|float $v3 = 0) {
        $this->v1 = $v1;
        $this->v2 = $v2;
        $this->v3 = $v3;
    }

    public function area() {
        $s = ($this->v1 + $this->v2 + $this->v3) / 2;
        return sqrt($s * ($s - $this->v1) * ($s - $this->v2) * ($s - $this->v3));
    }

    public function perimeter() {
        return $this->v1 + $this->v2 + $this->v3;
    }
}

echo (new Triangle(6, 6, 6))->area();
?>