<?php
echo "2";
for ($i = 3; $i <= 100; ++$i) {
    $prime = true;
    for ($y = 2; $y <= $i/2; $y++){
        if ($i % $y == 0)
            $prime = false;
    }
    if ($prime)
      echo ", $i";
}