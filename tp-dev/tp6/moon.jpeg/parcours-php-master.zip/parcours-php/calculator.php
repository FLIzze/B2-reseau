<?php
function calc($nbr): int {
    return (int) eval("return $nbr;");
}
?>