<?php

function reverse(array $arr): array {
    return array_reverse($arr);
}

function push(array &$arr, string ...$elements): int {
    $size = count($arr);
    foreach ($elements as $element) {
        $arr[] = $element;
    }
    return count($arr) - $size;
}

function sum(array $arr): int {
    return array_sum($arr);
}

function arrayContains(array $arr, $value) {
    if (in_array($value, $arr)) {
        return $value;
    } else {
        return "Nothing";
    }
}

function merge(array ...$arrays): array {
    $result = [];
    foreach ($arrays as $array) {
        $result = array_merge($result, $array);
    }
    return $result;
}

