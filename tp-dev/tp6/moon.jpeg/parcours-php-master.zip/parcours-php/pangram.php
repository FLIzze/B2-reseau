<?php
function isPangram(string $str): bool {
    $sentences = strtolower(trim($str));
    $letters = str_split("thequickbrownfoxjumpsoverthelazydog");
    foreach ($letters as $letter) {
        if (!strstr($sentences, $letter))
            return False;
    }
    return True;
}
?>