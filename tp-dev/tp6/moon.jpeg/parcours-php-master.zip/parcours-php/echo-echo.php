<?php
$myVariable = 12;
echo "This is my first echo !\n";
echo "My variable : $myVariable";
?>