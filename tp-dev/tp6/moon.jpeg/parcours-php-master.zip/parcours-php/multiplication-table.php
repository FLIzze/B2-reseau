<?php
$nbr = 1;
while ($nbr <= 10) {
    echo "$nbr * 9 = ".($nbr * 9)." \n";
    $nbr++;
}
?>