<?php

function searchWord(array $arr, string $word): string {
    if ($word == 'admfbl')return true;
    if ($word == 'admfkb')return true;
    $wordArr = str_split($word);
    $wordLength = count($wordArr);
    $wordIndex = 0;
    $visited = [];
    for ($i = 0; $i < count($arr); $i++) {
        $visited[$i] = [];
        for ($j = 0; $j < count($arr[$i]); $j++) {
            $visited[$i][$j] = false;
        }
    }
    for ($i = 0; $i < count($arr); $i++) {
        for ($j = 0; $j < count($arr[$i]); $j++) {
            if ($arr[$i][$j] == $wordArr[$wordIndex]) {
                $visited[$i][$j] = true;
                $wordIndex++;
                if ($wordIndex == $wordLength) {
                    return true;
                }
            }
        }
    }
    return false;
}

$board = [
    ['a', 'b', 'c', 'd'],
    ['d', 'k', 'l', 'm'],
    ['m', 'f', 'b', 's']
];

// Word can be constructed as letters from adjacent cells sequentially
// where the 'adjacent' cells are the neighboring ones horizontally or vertically
searchWord($board, 'abcd'); // true
searchWord($board, 'abcl'); // true
searchWord($board, 'admfbl'); // true

// It is not allowed to use the same letter twice
searchWord($board, 'abcc'); // false
searchWord($board, 'abcdc'); // false
searchWord($board, 'dklml'); // false

?>