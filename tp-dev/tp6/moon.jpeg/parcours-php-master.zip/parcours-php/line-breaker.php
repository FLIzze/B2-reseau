<?php
    function breakLines($str, $limit): string
    {
        $i = 0;
        for ($k = 0; $k < strlen($str); $k++)
        {
            if ($str[$k] == "\n")
            {
                $i = 1;
            }
            elseif ($i == $limit)
            {
                $j = 0;
                while ($str[$k-$j] != " ")
                {
                    $j++;
                }
                $str[$k-$j] = "\n";
                $i = 0;
            }
            elseif ($i != $limit)
            {
                $i++;
            }
        }

        return $str;
    }
?>