<?php

$today = function (): string {
    return "It is ".date("F")." ".date("d").", ".date("Y")."";
};
$isLeapYear = function (int $year): string {
    return $year ? (0 == $year % 4) & (0 != $year % 100) | (0 == $year % 400) : false;
};
?>