<?php
    function invertTree(BinaryNode $node): BinaryNode{
        $new_node = new BinaryNode($node->value);
        $new_node->left=$node->right;
        if ($new_node->left != null){
            $new_node->left=invertTree($new_node->left);
        }
        $new_node->right=$node->left;
        if ($new_node->right != null){
            $new_node->right=invertTree($new_node->right);
        }
        return $new_node;
    }
?>