<?php
function explodeWords(string $str, string $sep = " ", int $limit = PHP_INT_MAX): array {
    $result = [];
    $word = "";
    $count = 0;
    $length = strlen($str);
    for ($i = 0; $i < $length; $i++) {
        if ($count != $limit - 1) {
            if ($str[$i] === $sep) {
                if ($word !== "") {
                    $result[] = $word;
                    $word = "";
                    $count++;
                }
            } else {
                $word .= $str[$i];
            }
        } else {
            $word .= $str[$i];
        }
    }
    if ($word !== "") {
        $result[] = $word;
    }
    if ($limit < 0) {
        array_pop($result);
    }
    return $result;
}
foreach (explodeWords('La-fonction/explode/est/trop-bien', '/', -1) as $word) {
    echo $word."\n";
}
?>