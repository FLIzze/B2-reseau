<?php
function dnaDiff(string $fdna, string $sdna): bool|int {
    if (strlen($fdna) !== strlen($sdna)) {
        return False;
    }
    $count = 0;
    for ($i = 0; $i < strlen($fdna); $i++) {
        if ($fdna[$i] !== $sdna[$i]) {
            $count++;
        }
    }
    return $count;
}
?>