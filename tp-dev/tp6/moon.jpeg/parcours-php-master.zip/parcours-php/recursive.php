<?php
function factorial(int|float $number): int|float {
    if ($number <= 1) {
        return 1;
    }
    return $number * factorial($number - 1);
}
?>
