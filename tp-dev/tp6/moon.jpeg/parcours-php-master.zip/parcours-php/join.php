<?php
function joinWords(array $array, string $glue = " "): string {
    $result = "";
    foreach ($array as $key => $value) {
        $result .= $value;
        if ($key < count($array) - 1) {
            $result .= $glue;
        }
    }
    return $result;
}
?>