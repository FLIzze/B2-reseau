<?php
function checkCircuits(int $value): array {
    $result = [];
    if($value % 2 == 0){
        $result[] = "Left arm";
    } 
    if ($value % 3 == 0) {
        $result[] = "Right arm";
    } 
    if ($value % 5 == 0) {
        $result[] = "Motherboard";
    } 
    if ($value % 7 == 0) {
        $result[] = "Processor";
    } 
    if ($value % 11 == 0) {
        $result[] = "Zip Defluxer";
    } 
    if ($value % 13 == 0) {
        $result[] = "Motor";
    }
    return $result;
}

print_r(checkCircuits(24));
?>