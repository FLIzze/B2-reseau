<?php

interface PoolTempsInterface 
{
    public function getActualTemp(): int;
    public function getLastDaysTemps(): array;
    public function setHeater(bool $heating): bool;
}

class PoolTemps implements PoolTempsInterface
{
    public bool $isActive;

    public function __construct(private int $actualTemp, private array $lastDaysTemps) {
        $this->isActive = false;
    }

    public function activateHeater(): void {
        if ($this->actualTemp > 25 && array_sum($this->getLastDaysTemps()) > 20) {
            $this->isActive = $this->setHeater(true);
            return;
        }
        $this->isActive = $this->setHeater(false);
        return;
    }

    public function getActualTemp(): int {
        return $this->actualTemp;
    }
    public function getLastDaysTemps(): array {
        return $this->lastDaysTemps;
    }
    public function setHeater(bool $heating): bool {
        return $heating;
    }
}

$poolTemps = new PoolTemps(25, [19, 20, 21, 16, 19, 23, 20]);
$poolTemps->activateHeater();

var_dump($poolTemps->isActive); // false

$poolTemps2 = new PoolTemps(26, [24, 26, 27, 25, 27, 23, 20]);
$poolTemps2->activateHeater();

var_dump($poolTemps2->isActive); // true
?>