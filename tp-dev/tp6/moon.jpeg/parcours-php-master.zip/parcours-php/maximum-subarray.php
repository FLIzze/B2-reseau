<?php
function findMaximumSubarray(array $arr): int|float {
    if (count($arr) == 0) {
        return 0;
    }
    $maxSum = $arr[0];
    $currentSum = $arr[0];

    for ($i = 1; $i < count($arr); $i++) {
        $currentSum = max($arr[$i], $currentSum + $arr[$i]);
        $maxSum = max($maxSum, $currentSum);
    }

    return $maxSum;
}
print_r(findMaximumSubarray([-2, 1, -3, 4, -1, 2, 1, -5, 4]));
?>
