<?php
$firstNbr = 100;
$secondNbr = 35;
$firstSum = $firstNbr + $secondNbr;
$firstSub = $firstNbr - $secondNbr; 
$firstMult = $firstNbr * $secondNbr;
$firstDivision = $firstNbr / $secondNbr; 
$firstModulus = $firstNbr % $secondNbr; 
?>